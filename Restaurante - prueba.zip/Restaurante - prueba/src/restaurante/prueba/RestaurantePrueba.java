package restaurante.prueba;

import java.util.Scanner;


public class RestaurantePrueba {


    public static void Mostrar(){
        System.out.println(" ====== Resumen del Pedido ======= ");
        System.out.println("Cliente: "+ nombre_completo);
        System.out.println("Direccion: "+direccion);
        System.out.println("Telefono: "+telefono);
        System.out.println("Tipo de comida: "+tipo);
        System.out.println("Dia"+dia);
        System.out.println("Precio Final: "+precioFinal);
        
    }
    
    
    public static clase2 dias[] = new clase2 [6]; 
    public static void main(String[] args) {
        
        dias[0] = new clase2();
        dias[0].setPrecio_economico(150);
        dias[0].setPrecio_regular(200);
        dias[0].setPrecio_premium(250);
        
        dias[1] = new clase2();
        dias[1].setPrecio_economico(100);
        dias[1].setPrecio_regular(210);
        dias[1].setPrecio_premium(300);
        
        dias[2] = new clase2();
        dias[2].setPrecio_economico(99);
        dias[2].setPrecio_regular(150);
        dias[2].setPrecio_premium(200);
        
        dias[3] = new clase2();
        dias[3].setPrecio_economico(150);
        dias[3].setPrecio_regular(200);
        dias[3].setPrecio_premium(250);
        
        dias[4] = new clase2();
        dias[4].setPrecio_economico(200);
        dias[4].setPrecio_regular(250);
        dias[4].setPrecio_premium(300);
        
        dias[5] = new clase2();
        dias[5].setPrecio_economico(120);
        dias[5].setPrecio_regular(190);
        dias[5].setPrecio_premium(220);
        
        Scanner entrada = new Scanner(System.in);
        
        System.out.println(" ======= 🎀Información del Cliente🎀 ======== ");
        System.out.println(" ");
        System.out.println("Ingrese el nombre completo del cliente: ");
        String nombre_completo= entrada.nextLine();
        System.out.println(" ");
        
        System.out.println("Ingrese la dirección del cliente: ");
        String direccion= entrada.nextLine();
        System.out.println(" ");
        
        System.out.println("Ingrese el número telefonico del cliente: ");
        int telefono = entrada.nextInt();
        System.out.println(" ");
        
        System.out.println("Es mayor de edad?: (true/false) ");
        boolean Mayor = entrada.nextBoolean();
        System.out.println(" ");
        
        System.out.println("Es cliente frecuente?: (true/false)");
        boolean frecuencia = entrada.nextBoolean();
        System.out.println(" ");
        
        System.out.println("========= 🎀Información del Pedido🎀 ======= ");
        System.out.println(" ");
        System.out.println("Tipo de comida (economico, regular, premium): ");
        String tipo = entrada.nextLine();
        System.out.println(" ");
        System.out.println("Ingrese el día de la semana: ");
        String dia = entrada.nextLine();
        
        double descuento = 0;
        if (frecuencia==true){
            descuento+= 0.15;   
        }
        if (!Mayor){
           descuento += 0.10; 
            
        }
        
        double precioBase =0;
        switch(tipo(economico)){
            
            
            
        }
        
        double precioFinal = precioBase * (1-descuento);
        
        Mostrar();
        
        
        
        
        
        
        
         
        
        
        
        
        
        
        
        
        
    }
    
}

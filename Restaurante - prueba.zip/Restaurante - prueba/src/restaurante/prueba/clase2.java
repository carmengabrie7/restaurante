/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurante.prueba;



public class clase2 extends clase1 {
    double precio_economico;
    double precio_regular;
    double precio_premium;

    public double getPrecio_economico() {
        return precio_economico;
    }

    public void setPrecio_economico(double precio_economico) {
        this.precio_economico = precio_economico;
    }

    public double getPrecio_regular() {
        return precio_regular;
    }

    public void setPrecio_regular(double precio_regular) {
        this.precio_regular = precio_regular;
    }

    public double getPrecio_premium() {
        return precio_premium;
    }

    public void setPrecio_premium(double precio_premium) {
        this.precio_premium = precio_premium;
    }
    
}
